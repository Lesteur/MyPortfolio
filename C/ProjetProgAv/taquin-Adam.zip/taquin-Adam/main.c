#include "f_taquin.h"

// Utilisé pour la fin de partie
bool g_Victoire = false;

int main() {
    Taquin * taquin;
    clock_t debut,fin; //début/fin d'exécution
    float temps_passe = 0.0;
    int n = 1;
    //int saisie_taille = -1;
    srand(time(NULL));
    SDL_InitAll();
    
    system("clear");
    int erreur_taille = 0;
    int menu = 1;
    bool image = false;
    while (menu != 0) {
        char rep;
        printf("Quel taquin voulez-vous faire ?\n\n1) Un aléatoire \n2) Un importé d'un fichier\n3) Un taquin avec une image \n4) Quitter\n");
        scanf("%c", &rep);

        switch(rep) {
            case '1': {
                while (n < 2) {
                    printf("Saisissez une taille supérieure ou égale à 2 : ");
                    /* if (scanf("%d%*c",&saisie_taille) != 1) {printf(PRINT_COLOR_RED"Saisie invalide ! Impossible de prendre la valeur \n"PRINT_COLOR_RESET);scanf("%d%*c",&saisie_taille);} */
                    /* else { */
                    /*     printf("ok\n"); */
                    /*     n = saisie_taille; */
                    /* } */
                    if(scanf("%d",&n) != 1) {
                        menu = 1;
                        erreur_taille = 1;
                        break;
                    }
                    else {
                        erreur_taille = 0;
                    }
                }
                if (erreur_taille == 0) {
                menu = 0;
                taquin = CreerTaquin(n);
                InitTaquin(taquin, 100);
                }
                else {
                    printf(PRINT_COLOR_RED"Saisie de la taille invalide\n"PRINT_COLOR_RESET);
                }

                break;
            }
            case '2':
                printf("Entrez le nom du fichier (max 30 caractères) : ");

                char str_file[30];
                scanf("%s", str_file);

                FILE * file = fopen(str_file, "r");
                if (file != NULL) {
                    taquin = ImportTaquin(file);
                    if (taquin == NULL) {
                        printf(PRINT_COLOR_RED"Fichier invalide selon le modèle donné...\n"PRINT_COLOR_RESET);
                        break;
                    }
                    n = taquin->taille; //n va recevoir la taille du taquin saisi
                    menu = 0;
                } else {
                    system("clear");
                    printf(PRINT_COLOR_RED"Ce fichier est inexistant ou invalide.\n\n"PRINT_COLOR_RESET);
                }
                break;
            case '3' :
                image = true;
            	menu = 0;
            	n = 4;
                taquin = CreerTaquin(n);
                InitTaquin(taquin, 100);
                break;
            case '4' : {
                free(taquin); // on libère le taquin
                SDL_Quit(); //on quitte la sdl
                printf(PRINT_COLOR_RED"Arrêt du programme via l'option '3'\n"PRINT_COLOR_RESET);
                exit(EXIT_SUCCESS); // on arrête la fonction principale
                break;
            }
            default :
            {
                printf(PRINT_COLOR_RED"Saisie invalide ! \n"PRINT_COLOR_RESET);
                break;

            }
        }
    }

    SDL_Window * window = NULL;
    if (image == false)
    	window = CreerFenetre("Taquin", 80*n, 80*n);
    else
    	window = CreerFenetre("Taquin", 600, 600);
    	
    if (!window) {
        exit(EXIT_FAILURE);
    }

    SDL_Renderer * renderer = CreerRendu(window);
    if (!renderer) {
        exit(EXIT_FAILURE);
    }

    SDL_Event event;
    TTF_Font * font = TTF_OpenFont("police.ttf", 40);

    if (!image) {
        if (!AfficherTaquin(taquin, renderer, font)) {
            // goto end?
            exit(EXIT_FAILURE);
        }
    } else {
        if (!AfficherImage(taquin, renderer)) {
            // goto end?
            exit(EXIT_FAILURE);
        }
    }

    debut = clock();
    while (true) {
        SDL_WaitEvent(&event);

        switch(event.type) {
            case SDL_WINDOWEVENT:
                if (event.window.event == SDL_WINDOWEVENT_CLOSE) {
                    printf(PRINT_COLOR_RED"Arrêt du programme via fermeture manuelle\n"PRINT_COLOR_RESET);
                    goto end;
                }
                break;
            case SDL_KEYUP:
                SDL_RenderClear(renderer);

                switch (event.key.keysym.sym) {
                    case SDLK_UP:
                        BougeTaquin(taquin, HAUT);
                        break;
                    case SDLK_DOWN:
                        BougeTaquin(taquin, BAS);
                        break;
                    case SDLK_LEFT:
                        BougeTaquin(taquin, GAUCHE);
                        break;
                    case SDLK_RIGHT:
                        BougeTaquin(taquin, DROITE);
                        break;
                    case 'q':
                        printf(PRINT_COLOR_RED"Arrêt du programme via la touche 'q'\n"PRINT_COLOR_RESET);
                        goto end;
                }

                if (VerifTab(taquin)) {
                    // Variable globale modifée pour la fonction `AfficherTaquin` afin de remplir en
                    // vert chaque case du puzzle.
                    g_Victoire = true;
                }
                
                if (image == true)
                    AfficherImage(taquin, renderer);                
                else
                    AfficherTaquin(taquin, renderer, font);

                if (g_Victoire) {
                    fin = clock();
                    temps_passe = (float)(fin - debut) / CLOCKS_PER_SEC;
                    printf(PRINT_COLOR_YELLOW"Le puzzle a été résolu en %.3f secondes",temps_passe, PRINT_COLOR_RESET);
                    goto end;
                }
            break;
        }
    }
 end:
    // Libère les ressources
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    TTF_Quit();
    FreeTaquin(taquin);
    printf(PRINT_COLOR_RED"Arrêt normal du programme\n"PRINT_COLOR_RESET);
    exit(EXIT_SUCCESS);
}
